# DATA_MODEL.md

## 1. Core Entities
```txt
users
roles
permissions
role_user
personnel
positions
departments
department_members
academic_years
terms
teachers
subjects
room_types
rooms
grade_levels
class_sections
timeslots
homeroom_assignments
teaching_assignments
timetables
timetable_entries
conflict_logs
quality_scores
quality_score_details
recommendations
recommendation_items
audit_logs
ai_prompt_logs
```

## 2. Key Relations
- users 1:1 personnel
- personnel M:N departments ผ่าน department_members
- users M:N roles ผ่าน role_user
- teachers มีหลาย teaching_assignments
- subjects มีหลาย teaching_assignments
- class_sections มีหลาย teaching_assignments
- rooms มีหลาย timetable_entries
- timeslots มีหลาย timetable_entries
- timetables มีหลาย timetable_entries
- timetable_entries อ้างอิง teaching_assignments
- timetables มี quality_scores
- quality_scores มี quality_score_details
- timetables มี recommendations
- recommendations มี recommendation_items

## 3. Important Tables
### teachers
- id
- personnel_id
- department_id
- teacher_code
- max_periods_per_week
- is_active

### subjects
- id
- code
- name
- subject_type
- difficulty_level
- periods_per_week
- required_room_type_id
- is_active

### rooms
- id
- code
- name
- room_type_id
- capacity
- check_room_conflict
- check_capacity
- is_shared
- is_active

### class_sections
- id
- grade_level_id
- name
- student_count
- academic_year_id
- term_id
- is_active

### homeroom_assignments
- id
- teacher_id
- class_section_id
- academic_year_id
- term_id

### teaching_assignments
- id
- teacher_id
- subject_id
- class_section_id
- academic_year_id
- term_id
- periods_per_week
- required_room_type_id
- priority_level
- notes

### timetable_entries
- id
- timetable_id
- teaching_assignment_id
- timeslot_id
- room_id
- status
- source_type
- notes

### conflict_logs
- id
- timetable_entry_id
- conflict_type
- severity
- message
- related_entry_id

### quality_scores
- id
- timetable_id
- score
- analyzed_at

### recommendations
- id
- timetable_id
- title
- description
- before_score
- after_score
- status
