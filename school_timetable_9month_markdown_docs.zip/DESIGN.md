# DESIGN.md

## 1. Architecture
```txt
Laravel Web App
  ↓
Controllers
  ↓
Application Services
  ↓
Scheduling Services
  - SchedulingEngine
  - ConstraintChecker
  - QualityAnalyzer
  - RecommendationEngine
  - ExplanationService
  ↓
Database
```

## 2. Service Layer
### app/Services/Scheduling
- SchedulingEngine.php
- ConstraintChecker.php
- QualityAnalyzer.php
- RecommendationEngine.php

### app/Services/AI
- AIProviderInterface.php
- RuleBasedExplanationProvider.php
- KkuIntelsphereProvider.php
- ExplanationService.php

### app/Services/Reports
- TimetableExportService.php
- QualityReportService.php

## 3. UI Principles
- Thai-first
- ทางการ
- ไม่สีจัด
- ตารางอ่านง่าย
- ปุ่มชัดเจน
- Badge: แดง conflict, เหลือง warning, เขียว passed
- Desktop-first

## 4. Menu Structure
```txt
Dashboard

ข้อมูลกลาง
- บุคลากร
- ครู
- กลุ่มสาระ
- วิชา
- ห้องเรียน / สถานที่
- ชั้นเรียน
- คาบเรียน

ภาระสอน
- Teaching Assignment
- ครูประจำชั้น
- ภาระครู

ตารางสอน
- สร้างตาราง
- ตารางตามชั้นเรียน
- ตารางตามครู
- ตารางตามห้อง

ตรวจสอบและวิเคราะห์
- Conflict
- Quality Score
- Recommendation

รายงาน
- Export ตารางเรียน
- Export ตารางครู
- รายงานคุณภาพ
```

## 5. Algorithm Strategy
MVP ใช้ Greedy/Heuristic ก่อน:
1. จัดงานที่ยากก่อน เช่น ต้องใช้ห้องพิเศษ
2. ตรวจ hard constraints ระหว่างจัด
3. ถ้าจัดไม่ได้ เก็บ failure reason
4. หลังจัดเสร็จ วิเคราะห์ quality score

## 6. AI Strategy
AI ไม่ใช่ตัวจัดตารางหลัก ใช้ช่วยอธิบายผลเท่านั้น และต้อง fallback เป็น Rule-based ได้เสมอ
