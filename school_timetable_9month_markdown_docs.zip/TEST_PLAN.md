# TEST_PLAN.md

## 1. Test Strategy
ทดสอบ logic สำคัญก่อน UI โดยเน้น ConstraintChecker, QualityAnalyzer, RecommendationEngine

## 2. Unit Tests
- Teacher conflict
- Room conflict
- Class conflict
- Room type mismatch
- Capacity check
- Shared room bypass
- Consecutive teaching warning
- Heavy subject clustering
- Quality score calculation
- Recommendation score comparison

## 3. Feature Tests
- Admin creates master data
- Academic staff creates teaching assignment
- Manual timetable entry with no conflict
- Timetable entry with teacher conflict
- Homeroom teacher exports class timetable
- Teacher views own timetable
- Viewer sees dashboard read-only

## 4. E2E Scenarios
### Scenario 1: Basic Feasible Schedule
Expected: conflict = 0, score > 80

### Scenario 2: Teacher Conflict
Expected: system blocks save or shows red error

### Scenario 3: Shared Room
Expected: no room conflict

### Scenario 4: Heavy Subjects Clustered
Expected: score decreases and warning appears

### Scenario 5: Recommendation Improvement
Expected: after_score >= before_score

## 5. Acceptance Gate
ก่อนนำเสนอ final ต้องผ่าน:
- Feature tests สำคัญ
- Demo flow สมบูรณ์
- Export ได้
- Dashboard แสดงข้อมูลครบ
- ไม่มี bug blocking
