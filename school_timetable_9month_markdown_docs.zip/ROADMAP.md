# ROADMAP.md

## Total Timeline: 9 Months
โครงสร้างเวลา:
- เทอม 1: 4 เดือน - นำเสนอรายละเอียดทั้งหมดที่จะทำ
- ปิดเรียน: 1 เดือน - เตรียม repo/environment และ prototype risk reduction
- เทอม 2: 4 เดือน - พัฒนาโปรเจคจริง ทดสอบ และนำเสนอจบ

## Term 1: Proposal & Design Phase (Month 1-4)
### Month 1: Project Foundation
- สรุปหัวข้อ
- วิเคราะห์ปัญหา
- ศึกษาโปรแกรมจัดตารางที่มีอยู่
- สรุปจุดต่างของโปรเจค
- ทำ PRODUCT.md และ DOMAIN.md

### Month 2: Requirements & Workflows
- เก็บ requirements
- วิเคราะห์ user roles
- เขียน REQUIREMENTS.md
- เขียน WORKFLOWS.md
- ทำ flowchart

### Month 3: Data Model & Design
- ออกแบบ ERD
- เขียน DATA_MODEL.md
- ออกแบบ architecture
- ออกแบบ UI wireframe
- เขียน DESIGN.md
- เขียน TEST_PLAN.md

### Month 4: Proposal Presentation
- จัดทำ proposal
- ทำ slide
- เตรียม demo concept
- ตรวจเอกสารกับอาจารย์
- นำเสนอหัวข้อและขอบเขต

## Break Month (Month 5)
- Setup Laravel project
- เตรียม GitHub
- เตรียม docs สำหรับ AI
- เตรียม seed data
- ทำ prototype เฉพาะ logic ยาก เช่น ConflictChecker

## Term 2: Implementation & Final Presentation (Month 6-9)
### Month 6: Foundation Implementation
- Laravel setup
- Auth/RBAC
- Master Data
- Academic Year/Term
- Personnel/Department

### Month 7: Scheduling Core
- Teaching Assignment
- Manual Timetable
- Timetable Views
- Real-time Conflict Checker

### Month 8: Analysis & Recommendation
- Timetable Generator
- Quality Analyzer
- Recommendation Engine
- Rule-based Explanation
- Dashboard/Export

### Month 9: Testing & Final Delivery
- Feature tests
- Bug fixing
- Demo data
- Final report
- Final presentation
- Rehearsal
