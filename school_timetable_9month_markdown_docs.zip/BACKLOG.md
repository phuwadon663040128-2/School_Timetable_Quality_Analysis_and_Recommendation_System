# BACKLOG.md

## Epic 1: Documentation & Proposal
- สรุป problem statement
- วิเคราะห์ระบบเดิมและคู่แข่ง
- เขียน PRODUCT.md
- เขียน DOMAIN.md
- เขียน REQUIREMENTS.md
- เขียน WORKFLOWS.md
- ทำ flowchart
- ทำ proposal presentation

## Epic 2: User & Role
User Story: ในฐานะผู้ดูแลระบบ ฉันต้องการกำหนดสิทธิ์ผู้ใช้ เพื่อให้แต่ละบทบาทเห็นเมนูตามหน้าที่
Tasks:
- Setup Laravel Breeze
- Create roles/permissions
- Role middleware
- Role switching optional
- Tests

## Epic 3: Master Data
User Story: ในฐานะฝ่ายวิชาการ ฉันต้องการจัดการข้อมูลครู วิชา ห้องเรียน และชั้นเรียน เพื่อใช้เป็นข้อมูลกลาง
Tasks:
- Teachers CRUD
- Subjects CRUD
- Rooms CRUD
- Room Types CRUD
- Grade Levels CRUD
- Class Sections CRUD
- Timeslots CRUD
- Validation and tests

## Epic 4: Teaching Assignment
Tasks:
- Create teaching_assignments table
- Build assignment page
- Workload summary
- Department filtering
- Tests

## Epic 5: Timetable
Tasks:
- Create timetables and entries
- Manual timetable editor
- View by class
- View by teacher
- View by room
- Copy entry optional

## Epic 6: Conflict Checker
Tasks:
- checkTeacherConflict
- checkRoomConflict
- checkClassConflict
- checkRoomTypeMismatch
- checkRoomCapacity
- shared room logic
- UI warnings/errors
- Unit tests

## Epic 7: Generator
Tasks:
- Greedy scheduling engine
- Sort hard tasks first
- Failure report
- Generated timetable view
- Tests

## Epic 8: Quality & Recommendation
Tasks:
- Quality scoring rules
- Teacher consecutive periods
- Heavy subject clustering
- Workload balance
- Room utilization
- Recommendation before/after score

## Epic 9: Explanation & Reports
Tasks:
- Rule-based explanation
- AI provider interface optional
- Export timetable
- Export quality report
- Dashboard
- Final demo
