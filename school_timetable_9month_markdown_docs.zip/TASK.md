# TASK.md

## Current Focus
เตรียมเอกสารโปรเจคจบ 9 เดือนก่อนเริ่มเขียนโค้ด

## Active Tasks
- [ ] Finalize PRODUCT.md
- [ ] Finalize DOMAIN.md
- [ ] Finalize REQUIREMENTS.md
- [ ] Finalize DATA_MODEL.md
- [ ] Finalize WORKFLOWS.md
- [ ] Finalize ROADMAP.md
- [ ] Finalize BACKLOG.md
- [ ] Finalize TEST_PLAN.md

## Scope Boundary
ห้ามเริ่มทำ feature นอก MVP ก่อนเอกสารหลักเสร็จ
