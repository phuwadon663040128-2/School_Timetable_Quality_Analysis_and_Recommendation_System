# ระบบวิเคราะห์และเพิ่มประสิทธิภาพตารางสอนโรงเรียน

## Overview
ระบบวิเคราะห์และเพิ่มประสิทธิภาพตารางสอนโรงเรียน เป็นระบบต้นแบบสำหรับโปรเจคจบวิศวกรรมคอมพิวเตอร์ มีเป้าหมายเพื่อช่วยโรงเรียนบริหารข้อมูลตารางสอนอย่างเป็นระบบ โดยใช้ฐานข้อมูลกลาง ลดการกรอกซ้ำ ตรวจปัญหาตารางชน วิเคราะห์คุณภาพตาราง และส่งออกตารางตามบทบาทผู้ใช้

## Core Capabilities
1. School Master Data
2. Teaching Assignment
3. Manual Timetable
4. Timetable Generator
5. Real-time Conflict Checker
6. Quality Analyzer
7. Recommendation Engine
8. Rule-based / AI-assisted Explanation
9. Dashboard & Reports
10. Export / Print

## Tech Stack
- Laravel
- PHP
- MySQL
- Blade
- TailwindCSS
- Alpine.js
- Laravel Breeze
- PHPUnit / Feature Tests
- Optional AI Provider: KKU Intelsphere API

## Main Users
- Admin / ฝ่ายวิชาการ
- หัวหน้างานวิชาการ
- หัวหน้ากลุ่มสาระ
- ครูผู้สอน
- ครูประจำชั้น
- ผู้บริหาร / Viewer

## MVP
- Login + Role
- Master Data
- Teaching Assignment
- Manual Timetable
- Conflict Checker
- Quality Score
- Recommendation เบื้องต้น
- Rule-based Explanation
- Export ตารางครู/ห้องเรียน/ชั้นเรียน
