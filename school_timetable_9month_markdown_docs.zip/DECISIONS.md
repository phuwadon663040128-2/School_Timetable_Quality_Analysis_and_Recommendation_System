# DECISIONS.md

## Decision Log

### D-001: ไม่ทำ role นักเรียนใน MVP
เหตุผล: บริบทโรงเรียนไทยสามารถเผยแพร่ตารางผ่านครูประจำชั้นได้ และลด scope

### D-002: AI ไม่ใช่ตัวจัดตารางหลัก
เหตุผล: Scheduling ต้องอธิบายได้และ test ได้ จึงใช้ algorithm/rule เป็นแกน AI ใช้เฉพาะ explanation

### D-003: เริ่มจาก manual scheduling + conflict checker ก่อน generator
เหตุผล: ถ้าตรวจ conflict ไม่แม่น generator จะสร้างผลลัพธ์ผิด

### D-004: หัวหน้ากลุ่มสาระไม่ publish ตารางรวมใน MVP
เหตุผล: ตารางมี conflict ข้ามกลุ่มสาระ จึงให้ฝ่ายวิชาการเป็นผู้จัดรวม

### D-005: ครูประจำชั้นเป็น assignment
เหตุผล: เปลี่ยนได้ตามปีการศึกษา/ภาคเรียน

### D-006: Shared room/open area ใช้ field check_room_conflict และ check_capacity
เหตุผล: ห้องบางประเภท เช่น สนาม/ลานกิจกรรม ไม่ควรถูกตรวจแบบห้องเรียนปิด

### D-007: UI ต้องทางการ
เหตุผล: ผู้ใช้หลักคือบุคลากรโรงเรียน ไม่ใช่ consumer app
