# WORKFLOWS.md

## Overall Workflow
```txt
[Setup Master Data]
      ↓
[Set Academic Year / Term]
      ↓
[Create Homeroom & Teaching Assignment]
      ↓
[Manual Schedule or Generate]
      ↓
[Real-time Conflict Check]
      ↓
[Quality Analysis]
      ↓
[Recommendation]
      ↓
[Explanation]
      ↓
[Export / Print / Report]
```

## Workflow 1: Setup Master Data
Actor: Admin / ฝ่ายวิชาการ
1. เพิ่มปีการศึกษาและภาคเรียน
2. เพิ่มบุคลากร
3. เพิ่มกลุ่มสาระ
4. เพิ่มครู
5. เพิ่มวิชา
6. เพิ่มห้องและประเภทห้อง
7. เพิ่มระดับชั้นและห้องเรียน
8. เพิ่มคาบเรียน

## Workflow 2: Homeroom Assignment
Actor: ฝ่ายวิชาการ
1. เลือกปี/เทอม
2. เลือกห้องเรียน เช่น ม.2/1
3. เลือกครูประจำชั้น
4. บันทึก assignment

## Workflow 3: Teaching Assignment
Actor: ฝ่ายวิชาการ / หัวหน้ากลุ่มสาระ
1. เลือกครู
2. เลือกวิชา
3. เลือกห้องเรียน
4. กำหนดจำนวนคาบต่อสัปดาห์
5. กำหนดประเภทห้องที่ต้องใช้
6. ตรวจภาระสอนเบื้องต้น

## Workflow 4: Manual Timetable
Actor: ฝ่ายวิชาการ
1. เปิดหน้า timetable
2. เลือกวัน/คาบ/ชั้นเรียน
3. เลือก teaching assignment
4. เลือกห้อง
5. ระบบตรวจ conflict
6. ถ้าไม่มี conflict บันทึก
7. ถ้ามี conflict แสดง error/warning

## Workflow 5: Timetable Generator
Actor: ฝ่ายวิชาการ
1. กด Generate
2. ระบบดึง teaching assignment ทั้งหมด
3. เรียงงานที่จัดยากก่อน
4. หาคาบและห้องที่ไม่ชน
5. บันทึก entry
6. แสดง failure reason ถ้าจัดไม่ได้
7. วิเคราะห์ quality score

## Workflow 6: Quality Analysis
Actor: ฝ่ายวิชาการ / ผู้บริหาร
1. เลือก timetable
2. ระบบตรวจ soft constraints
3. แสดง score
4. แสดงรายการปัญหา
5. ส่งต่อ recommendation
